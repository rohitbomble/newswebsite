import React from 'react';
import { Link } from 'react-router-dom';
import { TrendingUp } from 'lucide-react';
import { Article } from '../types/news';

interface TrendingNewsProps {
  articles: Article[];
}

const TrendingNews: React.FC<TrendingNewsProps> = ({ articles }) => {
  const sortedArticles = [...articles].sort((a, b) => (b.views || 0) - (a.views || 0)).slice(0, 5);

  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <div className="flex items-center space-x-2 mb-4">
        <TrendingUp className="text-red-600" size={20} />
        <h2 className="text-lg font-bold text-gray-800">Trending Now</h2>
      </div>
      <div className="space-y-4">
        {sortedArticles.map((article, index) => (
          <Link
            key={article.id}
            to={`/article/${article.id}`}
            className="flex items-start space-x-4 group"
          >
            <span className="text-2xl font-bold text-gray-300 group-hover:text-red-600">
              {index + 1}
            </span>
            <div>
              <h3 className="text-gray-700 group-hover:text-blue-600 font-medium">
                {article.title}
              </h3>
              <span className="text-sm text-gray-500">{article.views?.toLocaleString()} views</span>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default TrendingNews;