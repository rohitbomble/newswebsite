import React from 'react';
import { Link } from 'react-router-dom';
import { Category } from '../types/news';

interface CategoryCardProps {
  category: Category;
}

const CategoryCard: React.FC<CategoryCardProps> = ({ category }) => {
  return (
    <Link 
      to={`/category/${category.name.toLowerCase()}`}
      className="relative h-48 rounded-lg overflow-hidden group"
    >
      <img 
        src={category.imageUrl} 
        alt={category.name}
        className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
      />
      <div className="absolute inset-0 bg-black/50 group-hover:bg-black/40 transition-colors">
        <div className="h-full flex flex-col justify-center items-center text-white p-4">
          <h3 className="text-2xl font-bold mb-2">{category.name}</h3>
          <p className="text-sm text-center text-gray-200">{category.description}</p>
        </div>
      </div>
    </Link>
  );
};

export default CategoryCard;