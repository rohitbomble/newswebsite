import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Newspaper } from 'lucide-react';
import SearchBar from './SearchBar';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2 text-2xl font-bold text-gray-800">
              <Newspaper className="text-blue-600" />
              <span>NewsHub</span>
            </Link>
          </div>

          <div className="hidden md:flex items-center space-x-8">
            <SearchBar />
            <Link to="/" className="text-gray-600 hover:text-gray-900">Home</Link>
            <Link to="/category/technology" className="text-gray-600 hover:text-gray-900">Technology</Link>
            <Link to="/category/politics" className="text-gray-600 hover:text-gray-900">Politics</Link>
            <Link to="/category/health" className="text-gray-600 hover:text-gray-900">Health</Link>
          </div>

          <div className="md:hidden flex items-center">
            <button 
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-600 hover:text-gray-900"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {isOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <SearchBar />
              <Link 
                to="/" 
                className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50"
                onClick={() => setIsOpen(false)}
              >
                Home
              </Link>
              <Link 
                to="/category/technology" 
                className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50"
                onClick={() => setIsOpen(false)}
              >
                Technology
              </Link>
              <Link 
                to="/category/politics" 
                className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50"
                onClick={() => setIsOpen(false)}
              >
                Politics
              </Link>
              <Link 
                to="/category/health" 
                className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50"
                onClick={() => setIsOpen(false)}
              >
                Health
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;