import React from 'react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { Clock } from 'lucide-react';
import { Article } from '../types/news';

interface ArticleCardProps {
  article: Article;
}

const ArticleCard: React.FC<ArticleCardProps> = ({ article }) => {
  const readingTime = Math.ceil(article.content.split(' ').length / 200);

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden group hover:shadow-xl transition-shadow duration-300">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={article.imageUrl} 
          alt={article.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute top-4 left-4">
          <span className="inline-block px-3 py-1 text-sm font-semibold bg-blue-600 text-white rounded-full">
            {article.category}
          </span>
        </div>
      </div>
      <div className="p-6">
        <h2 className="text-xl font-bold text-gray-800 mb-3 line-clamp-2 group-hover:text-blue-600 transition-colors">
          <Link to={`/article/${article.id}`}>
            {article.title}
          </Link>
        </h2>
        <p className="text-gray-600 mb-4 line-clamp-2">{article.content}</p>
        <div className="flex items-center justify-between text-sm text-gray-500">
          <span className="font-medium">{article.author}</span>
          <div className="flex items-center space-x-4">
            <span>{format(new Date(article.date), 'MMM d, yyyy')}</span>
            <span className="flex items-center">
              <Clock size={14} className="mr-1" />
              {readingTime} min
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ArticleCard;