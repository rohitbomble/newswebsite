import React from 'react';
import { Link } from 'react-router-dom';
import { AlertCircle } from 'lucide-react';
import { Article } from '../types/news';

interface BreakingNewsProps {
  articles: Article[];
}

const BreakingNews: React.FC<BreakingNewsProps> = ({ articles }) => {
  const breakingNews = articles.filter(article => article.isBreaking);

  if (breakingNews.length === 0) return null;

  return (
    <div className="bg-red-600 text-white py-2 px-4">
      <div className="max-w-7xl mx-auto flex items-center overflow-hidden">
        <div className="flex items-center space-x-2 shrink-0">
          <AlertCircle className="animate-pulse" size={20} />
          <span className="font-bold">BREAKING NEWS</span>
        </div>
        <div className="ml-4 overflow-hidden relative w-full">
          <div className="animate-marquee whitespace-nowrap">
            {breakingNews.map((news, index) => (
              <Link
                key={news.id}
                to={`/article/${news.id}`}
                className="inline-block mx-8 hover:text-gray-200"
              >
                {news.title}
                {index < breakingNews.length - 1 && (
                  <span className="mx-4">|</span>
                )}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BreakingNews;