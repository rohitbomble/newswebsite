import React from 'react';
import { Link } from 'react-router-dom';
import { Radio } from 'lucide-react';
import { Article, LiveUpdate } from '../types/news';

interface LiveNewsCardProps {
  article: Article;
  updates: LiveUpdate[];
}

const LiveNewsCard: React.FC<LiveNewsCardProps> = ({ article, updates }) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="relative">
        <img 
          src={article.imageUrl} 
          alt={article.title}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-4 left-4 flex items-center space-x-2">
          <span className="flex items-center space-x-1 bg-red-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
            <Radio className="animate-pulse" size={16} />
            <span>LIVE</span>
          </span>
        </div>
      </div>
      
      <div className="p-4">
        <h2 className="text-xl font-bold text-gray-800 mb-4">
          <Link to={`/article/${article.id}`} className="hover:text-blue-600">
            {article.title}
          </Link>
        </h2>
        
        <div className="space-y-4">
          {updates.map((update) => (
            <div key={update.id} className="border-l-2 border-red-600 pl-4">
              <span className="text-sm font-semibold text-gray-500">{update.time}</span>
              <p className="text-gray-700">{update.content}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LiveNewsCard;