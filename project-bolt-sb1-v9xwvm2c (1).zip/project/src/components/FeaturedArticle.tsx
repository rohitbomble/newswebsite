import React from 'react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { Article } from '../types/news';
import { Clock } from 'lucide-react';

interface FeaturedArticleProps {
  article: Article;
}

const FeaturedArticle: React.FC<FeaturedArticleProps> = ({ article }) => {
  const readingTime = Math.ceil(article.content.split(' ').length / 200); // Assuming 200 words per minute

  return (
    <div className="relative h-[500px] rounded-xl overflow-hidden group">
      <img 
        src={article.imageUrl} 
        alt={article.title}
        className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent">
        <div className="absolute bottom-0 p-8 text-white">
          <span className="inline-block px-4 py-1 mb-4 text-sm font-semibold bg-blue-600 rounded-full">
            {article.category}
          </span>
          <h2 className="text-4xl font-bold mb-4 leading-tight">
            <Link to={`/article/${article.id}`} className="hover:text-blue-400 transition-colors">
              {article.title}
            </Link>
          </h2>
          <p className="text-lg text-gray-200 mb-4 line-clamp-2">{article.summary}</p>
          <div className="flex items-center space-x-6 text-sm text-gray-300">
            <span>{article.author}</span>
            <span>•</span>
            <span>{format(new Date(article.date), 'MMMM d, yyyy')}</span>
            <span>•</span>
            <span className="flex items-center">
              <Clock size={16} className="mr-1" />
              {readingTime} min read
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FeaturedArticle;