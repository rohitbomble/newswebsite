import React from 'react';
import { useParams, Navigate, Link } from 'react-router-dom';
import { format } from 'date-fns';
import { Clock, ChevronLeft } from 'lucide-react';
import { articles } from '../data/articles';

const ArticlePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const article = articles.find(a => a.id === Number(id));
  const readingTime = Math.ceil(article?.content.split(' ').length ?? 0 / 200);

  if (!article) {
    return <Navigate to="/" replace />;
  }

  const relatedArticles = articles
    .filter(a => a.category === article.category && a.id !== article.id)
    .slice(0, 3);

  return (
    <article className="max-w-4xl mx-auto px-4 py-8">
      <Link 
        to="/" 
        className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-8"
      >
        <ChevronLeft size={20} />
        <span>Back to Home</span>
      </Link>

      <header className="mb-8">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">{article.title}</h1>
        <div className="flex items-center space-x-4 text-gray-600">
          <span className="font-medium">{article.author}</span>
          <span>•</span>
          <span>{format(new Date(article.date), 'MMMM d, yyyy')}</span>
          <span>•</span>
          <span className="flex items-center">
            <Clock size={16} className="mr-1" />
            {readingTime} min read
          </span>
        </div>
      </header>

      <img 
        src={article.imageUrl} 
        alt={article.title}
        className="w-full h-[500px] object-cover rounded-xl mb-8"
      />

      <div className="prose max-w-none">
        <p className="text-xl text-gray-600 mb-8 leading-relaxed">
          {article.summary}
        </p>
        <p className="text-gray-700 leading-relaxed whitespace-pre-line">
          {article.content}
        </p>
      </div>

      {relatedArticles.length > 0 && (
        <section className="mt-12 pt-8 border-t border-gray-200">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">Related Articles</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {relatedArticles.map(related => (
              <div key={related.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                <img 
                  src={related.imageUrl} 
                  alt={related.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-4">
                  <h3 className="font-semibold text-gray-800 mb-2">
                    <Link to={`/article/${related.id}`} className="hover:text-blue-600">
                      {related.title}
                    </Link>
                  </h3>
                  <span className="text-sm text-gray-500">
                    {format(new Date(related.date), 'MMM d, yyyy')}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}
    </article>
  );
};

export default ArticlePage;