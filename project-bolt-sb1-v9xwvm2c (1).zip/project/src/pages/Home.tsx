import React from 'react';
import { articles, liveUpdates } from '../data/articles';
import BreakingNews from '../components/BreakingNews';
import LiveNewsCard from '../components/LiveNewsCard';
import TrendingNews from '../components/TrendingNews';
import ArticleCard from '../components/ArticleCard';

const Home: React.FC = () => {
  const liveArticles = articles.filter(article => article.isLive);
  const regularArticles = articles.filter(article => !article.isLive && !article.isBreaking);

  return (
    <div>
      <BreakingNews articles={articles} />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Live Coverage Section */}
            {liveArticles.length > 0 && (
              <section>
                <h2 className="text-2xl font-bold text-gray-800 mb-4">Live Coverage</h2>
                <div className="space-y-6">
                  {liveArticles.map(article => (
                    <LiveNewsCard
                      key={article.id}
                      article={article}
                      updates={liveUpdates.filter(update => update.articleId === article.id)}
                    />
                  ))}
                </div>
              </section>
            )}

            {/* Latest News Section */}
            <section>
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Latest News</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {regularArticles.map(article => (
                  <ArticleCard key={article.id} article={article} />
                ))}
              </div>
            </section>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            <TrendingNews articles={articles} />
            
            {/* Ad Space */}
            <div className="bg-gray-100 rounded-lg p-4 text-center">
              <span className="text-gray-500">Advertisement Space</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;