import { Article, Category, LiveUpdate } from '../types/news';

export const categories: Category[] = [
  {
    name: "Breaking News",
    description: "Latest breaking news and updates",
    imageUrl: "https://images.unsplash.com/photo-1495020689067-958852a7765e?w=800&auto=format&fit=crop"
  },
  {
    name: "Politics",
    description: "Political news and analysis",
    imageUrl: "https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?w=800&auto=format&fit=crop"
  },
  {
    name: "Business",
    description: "Business and economy updates",
    imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop"
  },
  {
    name: "Technology",
    description: "Tech news and innovations",
    imageUrl: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&auto=format&fit=crop"
  },
  {
    name: "Entertainment",
    description: "Entertainment and celebrity news",
    imageUrl: "https://images.unsplash.com/photo-1586899028174-e7098604235b?w=800&auto=format&fit=crop"
  }
];

export const articles: Article[] = [
  {
    id: 1,
    title: "BREAKING: Major Political Breakthrough in Peace Talks",
    content: "In a historic development, world leaders have reached a breakthrough agreement in ongoing peace negotiations...",
    category: "Breaking News",
    author: "Sarah Johnson",
    date: "2024-03-15T10:30:00",
    imageUrl: "https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?w=800&auto=format&fit=crop",
    featured: true,
    isBreaking: true,
    summary: "World leaders achieve historic breakthrough in peace negotiations",
    views: 15420,
    tags: ["Peace Talks", "International", "Diplomacy"]
  },
  {
    id: 2,
    title: "LIVE: Stock Market Soars to Record Heights",
    content: "Markets are experiencing unprecedented gains as tech stocks lead a remarkable rally...",
    category: "Business",
    author: "Michael Chen",
    date: "2024-03-15T09:45:00",
    imageUrl: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800&auto=format&fit=crop",
    featured: true,
    isLive: true,
    summary: "Live coverage of historic market rally",
    views: 12800,
    tags: ["Stock Market", "Finance", "Business"]
  },
  {
    id: 3,
    title: "Tech Giant Unveils Revolutionary AI Platform",
    content: "A leading technology company has announced a groundbreaking artificial intelligence platform that promises to transform various industries...",
    category: "Technology",
    author: "David Wilson",
    date: "2024-03-15T08:15:00",
    imageUrl: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&auto=format&fit=crop",
    isBreaking: true,
    summary: "New AI platform set to revolutionize multiple industries",
    views: 8900,
    tags: ["AI", "Technology", "Innovation"]
  }
];

export const liveUpdates: LiveUpdate[] = [
  {
    id: 1,
    time: "10:45 AM",
    content: "Markets continue to surge as tech sector leads gains",
    articleId: 2
  },
  {
    id: 2,
    time: "10:30 AM",
    content: "Breaking: Asian markets respond positively to US rally",
    articleId: 2
  },
  {
    id: 3,
    time: "10:15 AM",
    content: "Expert Analysis: What's driving today's market surge?",
    articleId: 2
  }
];