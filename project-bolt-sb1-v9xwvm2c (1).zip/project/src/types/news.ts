export interface Article {
  id: number;
  title: string;
  content: string;
  category: string;
  author: string;
  date: string;
  imageUrl: string;
  featured?: boolean;
  summary?: string;
  isBreaking?: boolean;
  isLive?: boolean;
  views?: number;
  tags?: string[];
}

export type Category = {
  name: string;
  description: string;
  imageUrl: string;
}

export type LiveUpdate = {
  id: number;
  time: string;
  content: string;
  articleId: number;
}